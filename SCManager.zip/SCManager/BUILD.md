# SC Manager — How to build and install the APK

## Current status (honest)

This is a **source project**, not a finished Play Store app.

| Area | Status |
|------|--------|
| UI (Explorer, tools, APK tools screens) | Done (usable) |
| Real file list / copy / move / delete | Done |
| Extract APK to `SCManager/apks` | Done |
| Read strings from APK (plain XML) | Done |
| Optimize (recompress) | Partial (real recompress) |
| Sign APK | Structure only (needs working keystore + apksig test on device) |
| Dex open + Smali view/edit/save | Done (needs Gradle sync for smali libs) |
| Clone / Kill signature / full ARSC | UI + stubs |

You can produce an installable **debug APK** as soon as the project compiles on your PC.

## Requirements

- Android Studio Ladybug / Koala or newer (or command-line SDK)
- JDK 17
- Android device or emulator (API 24+)
- On device: grant **All files access** for full storage

## Build steps (Android Studio)

1. Copy the folder `SCManager/` to your computer.
2. Open it with **Open** → select the `SCManager` directory.
3. Wait for **Gradle Sync** (downloads Compose, smali, apksig).
4. If Sync fails on smali packages, check internet / Maven Central.
5. Connect phone (USB debugging) or start an emulator.
6. Click **Run** (green triangle).

### Build APK file only

```bash
cd SCManager
./gradlew assembleDebug
```

Output:

```
app/build/outputs/apk/debug/app-debug.apk
```

Install:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## First run

1. Open **SC Manager**.
2. Allow storage / “All files access” when asked.
3. Browse dual panes, Extract APK, open a `.dex`, edit Smali, etc.

## When is it “finished”?

- **Usable debug APK:** after first successful Gradle build on your machine (usually same day).
- **Feature-complete like MT Manager:** weeks of more work (ARSC editor, real sign/clone/kill-sig, polish, testing on many devices).

Priority order already followed: APK tools UI → file manager → DEX/Smali → extract.
