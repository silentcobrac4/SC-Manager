# SC Manager

Android file manager + APK tools (personal project inspired by public MT Manager features).  
**No accounts / no VIP — all tools open.**

## Build with GitHub Actions (recommended)

1. Create a new repository on GitHub (e.g. `SCManager`).
2. Upload this project (or push via git).
3. Open the **Actions** tab → workflow **Build SC Manager APK**.
4. Wait until the job is green.
5. Download artifact **`SC-Manager-debug-apk`**.
6. Install the APK on your phone (enable Install from unknown sources).

You can also click **Run workflow** manually under Actions → Build SC Manager APK → Run workflow.

## Build locally

```bash
# Android Studio: Open this folder, Sync, Run
# Or CLI:
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Requirements: JDK 17, Android SDK 34.

## Features (current)

- Dual-pane file explorer (list, copy, move, delete)
- Extract APK from installed apps → `SCManager/apks/`
- APK tools menu: Sign, Clone, Optimize, Xml Translation, Kill Signature, …
- Dex Editor + Smali view/edit (dexlib2 / smali)
- Dark theme

Some advanced tools are UI-complete with partial real logic; see `BUILD.md`.

## License

Personal project. Not affiliated with MT Manager.
