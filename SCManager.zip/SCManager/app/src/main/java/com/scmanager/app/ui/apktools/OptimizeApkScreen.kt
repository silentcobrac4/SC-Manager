package com.scmanager.app.ui.apktools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.scmanager.app.core.apk.ApkService
import com.scmanager.app.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File

enum class OptimizeState {
    Idle, Optimizing, Success, Error
}

@Composable
fun OptimizeApkScreen(
    apkName: String,
    apkPath: String,
    onBack: () -> Unit,
    onOptimized: (outputPath: String) -> Unit
) {
    val context = LocalContext.current
    val apkService = remember { ApkService(context) }

    var removeUnusedResources by remember { mutableStateOf(true) }
    var zipalign by remember { mutableStateOf(true) }
    var recompress by remember { mutableStateOf(true) }
    var removeMetaInf by remember { mutableStateOf(false) }
    var signAfter by remember { mutableStateOf(true) }
    var outputName by remember { mutableStateOf(apkName.removeSuffix(".apk") + "_optimized.apk") }

    var state by remember { mutableStateOf(OptimizeState.Idle) }
    var progressMessage by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var savedBytes by remember { mutableStateOf(0L) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Optimize APK", color = TextPrimary, fontSize = 16.sp)
                Text(
                    text = apkName,
                    color = TextMuted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Source
            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Source APK", color = TextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(apkPath, color = TextPrimary, fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Optimization options", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    OptCheckRow("Remove unused resources", removeUnusedResources) { removeUnusedResources = it }
                    OptCheckRow("Zipalign", zipalign) { zipalign = it }
                    OptCheckRow("Recompress (better ratio)", recompress) { recompress = it }
                    OptCheckRow("Remove META-INF signatures", removeMetaInf) { removeMetaInf = it }
                    OptCheckRow("Sign after optimize", signAfter) { signAfter = it }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Output file name", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = outputName,
                onValueChange = { outputName = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            when (state) {
                OptimizeState.Optimizing -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = Accent,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(progressMessage, color = TextMuted, fontSize = 14.sp)
                    }
                }
                OptimizeState.Success -> {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = Success)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Optimization completed", color = Success, fontSize = 14.sp)
                        }
                        if (savedBytes > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Saved approx. ${formatSize(savedBytes)}",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
                OptimizeState.Error -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Error, null, tint = Danger)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(errorMessage, color = Danger, fontSize = 14.sp)
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    scope.launch {
                        state = OptimizeState.Optimizing
                        progressMessage = "Optimizing..."
                        val outputPath = if (apkPath.contains("/")) {
                            apkPath.substringBeforeLast("/") + "/" + outputName
                        } else {
                            outputName
                        }
                        val originalSize = File(apkPath).length()
                        val result = if (recompress) {
                            apkService.recompress(apkPath, outputPath)
                        } else {
                            apkService.copyApk(apkPath, outputPath)
                        }
                        result
                            .onSuccess { outFile ->
                                if (signAfter) {
                                    progressMessage = "Signing..."
                                    apkService.sign(outFile.absolutePath, outFile.absolutePath)
                                }
                                savedBytes = (originalSize - outFile.length()).coerceAtLeast(0)
                                state = OptimizeState.Success
                                onOptimized(outFile.absolutePath)
                            }
                            .onFailure {
                                state = OptimizeState.Error
                                errorMessage = it.message ?: "Optimize failed"
                            }
                    }
                },
                enabled = state != OptimizeState.Optimizing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Accent,
                    contentColor = OnAccent,
                    disabledContainerColor = SurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Speed, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state == OptimizeState.Optimizing) "Optimizing..." else "Optimize APK",
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Note: Flow is simulated. Real optimization (resource shrinking, zipalign, recompress) will be implemented next.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun OptCheckRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = Accent,
                uncheckedColor = TextMuted,
                checkmarkColor = OnAccent
            )
        )
        Text(text = label, color = TextPrimary, fontSize = 14.sp)
    }
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        else -> "%.1f MB".format(bytes / (1024.0 * 1024))
    }
}
