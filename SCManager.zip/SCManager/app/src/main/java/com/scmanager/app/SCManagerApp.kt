package com.scmanager.app

import android.app.Application

class SCManagerApp : Application()
