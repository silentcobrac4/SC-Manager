package com.scmanager.app.ui.dex

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.core.dex.DexService
import com.scmanager.app.ui.theme.*
import kotlinx.coroutines.launch

// ---------- Models ----------

sealed class DexNode {
    abstract val name: String
    abstract val fullName: String

    data class Package(
        override val name: String,
        override val fullName: String,
        val children: List<DexNode>,
        val isExpanded: Boolean = false
    ) : DexNode()

    data class Class(
        override val name: String,
        override val fullName: String,
        val methods: List<DexMethod> = emptyList()
    ) : DexNode()
}

data class DexMethod(
    val name: String,
    val descriptor: String,
    val accessFlags: String = "public"
)

// ---------- Sample data (will be replaced by real dexlib2 parsing) ----------

private fun sampleDexTree(): List<DexNode> = listOf(
    DexNode.Package(
        name = "androidx",
        fullName = "androidx",
        children = listOf(
            DexNode.Package(
                name = "core",
                fullName = "androidx.core",
                children = listOf(
                    DexNode.Package(
                        name = "graphics",
                        fullName = "androidx.core.graphics",
                        children = listOf(
                            DexNode.Package(
                                name = "drawable",
                                fullName = "androidx.core.graphics.drawable",
                                children = listOf(
                                    DexNode.Class(
                                        name = "IconCompatParcelizer",
                                        fullName = "androidx.core.graphics.drawable.IconCompatParcelizer",
                                        methods = listOf(
                                            DexMethod("<init>", "()V"),
                                            DexMethod("read", "(Landroidx/versionedparcelable/VersionedParcel;)Landroidx/core/graphics/drawable/IconCompat;"),
                                            DexMethod("write", "(Landroidx/core/graphics/drawable/IconCompat;Landroidx/versionedparcelable/VersionedParcel;)V")
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )
    ),
    DexNode.Package(
        name = "com",
        fullName = "com",
        children = listOf(
            DexNode.Package(
                name = "example",
                fullName = "com.example",
                children = listOf(
                    DexNode.Class(
                        name = "MainActivity",
                        fullName = "com.example.MainActivity",
                        methods = listOf(
                            DexMethod("onCreate", "(Landroid/os/Bundle;)V"),
                            DexMethod("onResume", "()V")
                        )
                    )
                )
            )
        )
    ),
    DexNode.Package(name = "a", fullName = "a", children = emptyList()),
    DexNode.Package(name = "b", fullName = "b", children = emptyList())
)

// ---------- Screens ----------

@Composable
fun DexEditorScreen(
    dexName: String = "classes.dex",
    dexPath: String = "",
    onBack: () -> Unit,
    onOpenClass: (DexNode.Class) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    var nodes by remember { mutableStateOf(sampleDexTree()) }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    val dexService = remember { DexService() }

    LaunchedEffect(dexPath) {
        if (dexPath.isBlank()) return@LaunchedEffect
        isLoading = true
        loadError = null
        dexService.openDex(dexPath)
            .onSuccess { classes ->
                val tree = dexService.buildPackageTree(classes)
                nodes = packageNodeToDexNodes(tree)
                isLoading = false
            }
            .onFailure {
                loadError = it.message
                nodes = sampleDexTree()
                isLoading = false
            }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Dex Editor plus", color = TextPrimary, fontSize = 16.sp)
                Text(dexName, color = TextMuted, fontSize = 12.sp)
            }
            IconButton(onClick = { /* more options */ }) {
                Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
            }
        }

        // Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Surface,
            contentColor = Accent
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                text = { Text("EXPLORER", color = if (selectedTab == 0) Accent else TextMuted, fontSize = 12.sp) })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                text = { Text("HISTORY", color = if (selectedTab == 1) Accent else TextMuted, fontSize = 12.sp) })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                text = { Text("SEARCH", color = if (selectedTab == 2) Accent else TextMuted, fontSize = 12.sp) })
            Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 },
                text = { Text("STRINGS", color = if (selectedTab == 3) Accent else TextMuted, fontSize = 12.sp) })
        }

        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
        } else {
            if (loadError != null) {
                Text(
                    text = "Load warning: $loadError (showing sample)",
                    color = Warning,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
            when (selectedTab) {
                0 -> ExplorerTab(
                    nodes = nodes,
                    onToggle = { fullName ->
                        nodes = toggleExpand(nodes, fullName)
                    },
                    onOpenClass = onOpenClass
                )
                1 -> PlaceholderTab("History – recently opened classes")
                2 -> SearchTab(searchQuery, { searchQuery = it })
                3 -> PlaceholderTab("Strings – string pool view")
            }
        }
    }
}

/** Convert DexService package tree into UI DexNode list */
private fun packageNodeToDexNodes(
    node: com.scmanager.app.core.dex.DexPackageNode
): List<DexNode> {
    val result = mutableListOf<DexNode>()
    for ((_, child) in node.children.toSortedMap()) {
        result.add(
            DexNode.Package(
                name = child.name,
                fullName = child.fullName,
                children = packageNodeToDexNodes(child) + child.classes.map { cls ->
                    DexNode.Class(
                        name = cls.simpleName,
                        fullName = cls.type,
                        methods = cls.methods.map { m ->
                            DexMethod(name = m.name, descriptor = m.descriptor)
                        }
                    )
                }
            )
        )
    }
    // classes directly under this node (default package)
    for (cls in node.classes) {
        result.add(
            DexNode.Class(
                name = cls.simpleName,
                fullName = cls.type,
                methods = cls.methods.map { m ->
                    DexMethod(name = m.name, descriptor = m.descriptor)
                }
            )
        )
    }
    return result
}

@Composable
private fun ExplorerTab(
    nodes: List<DexNode>,
    onToggle: (String) -> Unit,
    onOpenClass: (DexNode.Class) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(flattenVisible(nodes)) { item ->
            DexTreeItem(
                node = item.node,
                depth = item.depth,
                onClick = {
                    when (val n = item.node) {
                        is DexNode.Package -> onToggle(n.fullName)
                        is DexNode.Class -> onOpenClass(n)
                    }
                }
            )
        }
    }
}

private data class FlatItem(val node: DexNode, val depth: Int)

private fun flattenVisible(nodes: List<DexNode>, depth: Int = 0): List<FlatItem> {
    val result = mutableListOf<FlatItem>()
    for (node in nodes) {
        result.add(FlatItem(node, depth))
        if (node is DexNode.Package && node.isExpanded) {
            result.addAll(flattenVisible(node.children, depth + 1))
        }
    }
    return result
}

private fun toggleExpand(nodes: List<DexNode>, fullName: String): List<DexNode> {
    return nodes.map { node ->
        when (node) {
            is DexNode.Package -> {
                if (node.fullName == fullName) {
                    node.copy(isExpanded = !node.isExpanded)
                } else {
                    node.copy(children = toggleExpand(node.children, fullName))
                }
            }
            is DexNode.Class -> node
        }
    }
}

@Composable
private fun DexTreeItem(
    node: DexNode,
    depth: Int,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = (12 + depth * 16).dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (node) {
            is DexNode.Package -> {
                Icon(
                    imageVector = if (node.isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.Default.Folder, null, tint = TextMuted, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(node.name, color = TextPrimary, fontSize = 14.sp)
            }
            is DexNode.Class -> {
                Spacer(modifier = Modifier.width(24.dp))
                Icon(Icons.Default.Code, null, tint = Accent, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(node.name, color = TextPrimary, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SearchTab(query: String, onQueryChange: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("Search classes / methods...", color = TextMuted) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Border,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = Accent
            )
        )
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Type to search", color = TextMuted)
        }
    }
}

@Composable
private fun PlaceholderTab(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(message, color = TextMuted)
    }
}

// ---------- Smali Editor ----------

@Composable
fun SmaliEditorScreen(
    className: String,
    dexPath: String = "",
    onBack: () -> Unit,
    onSave: (String) -> Unit
) {
    var code by remember { mutableStateOf("Loading...") }
    var hasChanges by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }
    var isSaving by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    val dexService = remember { DexService() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(className, dexPath) {
        isLoading = true
        saveMessage = null
        if (dexPath.isNotBlank() && className.isNotBlank()) {
            val type = if (className.startsWith("L") && className.endsWith(";")) {
                className
            } else {
                "L" + className.replace('.', '/') + ";"
            }
            dexService.classToSmali(dexPath, type)
                .onSuccess {
                    code = it
                    isLoading = false
                }
                .onFailure {
                    code = "// Failed to disassemble: ${it.message}\n// Class: $className"
                    isLoading = false
                }
        } else {
            code = "// No DEX path – sample placeholder for $className"
            isLoading = false
        }
    }

    fun performSave() {
        if (dexPath.isBlank()) {
            saveMessage = "No DEX path"
            onSave(code)
            return
        }
        scope.launch {
            isSaving = true
            saveMessage = null
            dexService.saveSmaliInPlace(dexPath, code)
                .onSuccess {
                    hasChanges = false
                    saveMessage = "Saved to DEX"
                    onSave(code)
                }
                .onFailure {
                    saveMessage = "Save failed: ${it.message}"
                }
            isSaving = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CodeBackground)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text(
                text = className.substringAfterLast('.'),
                color = TextPrimary,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = { /* undo */ }) {
                Icon(Icons.Default.Undo, contentDescription = "Undo", tint = TextMuted)
            }
            IconButton(onClick = { /* redo */ }) {
                Icon(Icons.Default.Redo, contentDescription = "Redo", tint = TextMuted)
            }
            if (hasChanges || isSaving) {
                IconButton(
                    onClick = { performSave() },
                    enabled = !isSaving
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            color = Accent,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = Accent)
                    }
                }
            }
            IconButton(onClick = { /* more */ }) {
                Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
            }
        }

        // Simple code editor (BasicTextField for now)
        OutlinedTextField(
            value = code,
            onValueChange = {
                code = it
                hasChanges = true
            },
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            textStyle = LocalTextStyle.current.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                color = TextPrimary,
                lineHeight = 18.sp
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Border,
                unfocusedBorderColor = Border,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = Accent,
                focusedContainerColor = CodeBackground,
                unfocusedContainerColor = CodeBackground
            )
        )
    }
}
