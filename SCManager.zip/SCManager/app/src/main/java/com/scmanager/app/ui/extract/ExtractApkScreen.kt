package com.scmanager.app.ui.extract

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.core.apk.ApkService
import com.scmanager.app.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File

data class InstalledApp(
    val name: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sourceDir: String,
    val isSystem: Boolean,
    val icon: android.graphics.drawable.Drawable?
)

@Composable
fun ExtractApkScreen(
    onBack: () -> Unit,
    onExtract: (InstalledApp, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val apkService = remember { ApkService(context) }

    var selectedTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf<List<InstalledApp>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var extractingPackage by remember { mutableStateOf<String?>(null) }
    var lastResult by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    // Default extract folder: /storage/emulated/0/SCManager/apks
    val extractDir = remember {
        File(
            Environment.getExternalStorageDirectory(),
            "SCManager/apks"
        )
    }

    LaunchedEffect(Unit) {
        isLoading = true
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        apps = packages.mapNotNull { appInfo ->
            try {
                val packageInfo = pm.getPackageInfo(appInfo.packageName, 0)
                InstalledApp(
                    name = appInfo.loadLabel(pm).toString(),
                    packageName = appInfo.packageName,
                    versionName = packageInfo.versionName ?: "?",
                    versionCode = packageInfo.longVersionCode,
                    sourceDir = appInfo.sourceDir ?: "",
                    isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    icon = appInfo.loadIcon(pm)
                )
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.name.lowercase() }
        isLoading = false
    }

    val filteredApps = remember(apps, selectedTab, searchQuery) {
        apps.filter { app ->
            val matchesTab = if (selectedTab == 0) !app.isSystem else app.isSystem
            val matchesSearch = searchQuery.isBlank() ||
                    app.name.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
            matchesTab && matchesSearch
        }
    }

    fun doExtract(app: InstalledApp) {
        if (app.sourceDir.isBlank()) {
            lastResult = false to "Source path empty"
            return
        }
        scope.launch {
            extractingPackage = app.packageName
            lastResult = null
            extractDir.mkdirs()
            val safeName = app.packageName.replace(".", "_")
            val destPath = File(extractDir, "${safeName}.apk").absolutePath

            apkService.extractInstalledApk(app.sourceDir, destPath)
                .onSuccess { file ->
                    lastResult = true to file.absolutePath
                    onExtract(app, file.absolutePath)
                }
                .onFailure {
                    lastResult = false to (it.message ?: "Extract failed")
                }
            extractingPackage = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Extract APK", color = TextPrimary, fontSize = 18.sp)
                Text(
                    text = "→ ${extractDir.absolutePath}",
                    color = TextMuted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = { }) {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = TextPrimary)
            }
        }

        lastResult?.let { (ok, msg) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (ok) Success.copy(alpha = 0.15f) else Danger.copy(alpha = 0.15f))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (ok) Icons.Default.CheckCircle else Icons.Default.Error,
                    null,
                    tint = if (ok) Success else Danger,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (ok) "Saved: $msg" else "Error: $msg",
                    color = if (ok) Success else Danger,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Surface,
            contentColor = Accent
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("USER APP", color = if (selectedTab == 0) Accent else TextMuted) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("SYSTEM APP", color = if (selectedTab == 1) Accent else TextMuted) }
            )
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search apps...", color = TextMuted) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Border,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = Accent
            )
        )

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredApps, key = { it.packageName }) { app ->
                    val isExtracting = extractingPackage == app.packageName
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isExtracting) { doExtract(app) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(SurfaceVariant, shape = MaterialTheme.shapes.small),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = app.name.take(1).uppercase(),
                                color = Accent,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = app.name,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${app.versionName}  •  ${app.packageName}",
                                color = TextMuted,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (isExtracting) {
                            CircularProgressIndicator(
                                color = Accent,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        }
                    }
                    HorizontalDivider(color = Border.copy(alpha = 0.4f))
                }
            }
        }
    }
}
