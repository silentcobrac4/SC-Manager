package com.scmanager.app.core.dex

import com.android.tools.smali.baksmali.BaksmaliOptions
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition
import com.android.tools.smali.dexlib2.DexFileFactory
import com.android.tools.smali.dexlib2.Opcodes
import com.android.tools.smali.dexlib2.iface.ClassDef
import com.android.tools.smali.dexlib2.iface.DexFile
import com.android.tools.smali.dexlib2.writer.builder.DexBuilder
import com.android.tools.smali.dexlib2.writer.io.FileDataStore
import com.android.tools.smali.smali.Smali
import com.android.tools.smali.smali.SmaliOptions
import com.android.tools.smali.util.IndentingWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.StringReader
import java.io.StringWriter

data class DexClassInfo(
    val type: String,          // e.g. Landroidx/core/graphics/drawable/IconCompatParcelizer;
    val simpleName: String,    // IconCompatParcelizer
    val packageName: String,   // androidx.core.graphics.drawable
    val methods: List<DexMethodInfo> = emptyList()
)

data class DexMethodInfo(
    val name: String,
    val descriptor: String,
    val accessFlags: Int = 0
)

data class DexPackageNode(
    val name: String,
    val fullName: String,
    val classes: MutableList<DexClassInfo> = mutableListOf(),
    val children: MutableMap<String, DexPackageNode> = mutableMapOf()
)

class DexService {

    suspend fun openDex(dexPath: String): Result<List<DexClassInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(dexPath)
            require(file.exists()) { "DEX not found: $dexPath" }

            val dexFile: DexFile = DexFileFactory.loadDexFile(file, Opcodes.getDefault())
            dexFile.classes.map { classDef ->
                toClassInfo(classDef)
            }.sortedBy { it.type }
        }
    }

    /**
     * Open classes.dex from inside an APK (entry name defaults to classes.dex).
     */
    suspend fun openDexFromApk(apkPath: String, entryName: String = "classes.dex"): Result<List<DexClassInfo>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val temp = File.createTempFile("sc_dex_", ".dex")
                try {
                    java.util.zip.ZipFile(File(apkPath)).use { zip ->
                        val entry = zip.getEntry(entryName)
                            ?: error("Entry not found in APK: $entryName")
                        zip.getInputStream(entry).use { input ->
                            temp.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                    openDex(temp.absolutePath).getOrThrow()
                } finally {
                    temp.delete()
                }
            }
        }

    suspend fun classToSmali(dexPath: String, classType: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val dexFile = DexFileFactory.loadDexFile(File(dexPath), Opcodes.getDefault())
                val classDef = dexFile.classes.find { it.type == classType }
                    ?: error("Class not found: $classType")

                val options = BaksmaliOptions()
                val writer = StringWriter()
                val indentingWriter = IndentingWriter(writer)
                val classDefinition = ClassDefinition(options, classDef)
                classDefinition.writeTo(indentingWriter)
                writer.toString()
            }
        }

    /**
     * Assemble smali text into a ClassDef, replace that class in the DEX, write a new DEX file.
     */
    suspend fun saveSmaliToDex(
        dexPath: String,
        smaliCode: String,
        outputPath: String
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val opcodes = Opcodes.getDefault()
            val original = DexFileFactory.loadDexFile(File(dexPath), opcodes)

            // Assemble the edited class
            val smaliOptions = SmaliOptions()
            val assembled: ClassDef = Smali.assemble(
                StringReader(smaliCode),
                smaliOptions
            ) ?: error("Failed to assemble smali")

            val newType = assembled.type

            // Rebuild DEX with replaced class
            val builder = DexBuilder(opcodes)
            for (cls in original.classes) {
                if (cls.type == newType) continue
                builder.internClassDef(cls)
            }
            builder.internClassDef(assembled)

            val outFile = File(outputPath)
            outFile.parentFile?.mkdirs()
            builder.writeTo(FileDataStore(outFile))
            outFile
        }
    }

    /**
     * Overwrite the same DEX path with assembled smali (writes to temp then replaces).
     */
    suspend fun saveSmaliInPlace(dexPath: String, smaliCode: String): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val temp = File.createTempFile("sc_dex_out_", ".dex")
                try {
                    saveSmaliToDex(dexPath, smaliCode, temp.absolutePath).getOrThrow()
                    val target = File(dexPath)
                    temp.copyTo(target, overwrite = true)
                    target
                } finally {
                    temp.delete()
                }
            }
        }

    fun buildPackageTree(classes: List<DexClassInfo>): DexPackageNode {
        val root = DexPackageNode(name = "", fullName = "")
        for (cls in classes) {
            val parts = cls.packageName.split('.').filter { it.isNotBlank() }
            var current = root
            var path = ""
            for (part in parts) {
                path = if (path.isEmpty()) part else "$path.$part"
                current = current.children.getOrPut(part) {
                    DexPackageNode(name = part, fullName = path)
                }
            }
            current.classes.add(cls)
        }
        return root
    }

    private fun toClassInfo(classDef: ClassDef): DexClassInfo {
        val type = classDef.type // e.g. Lcom/example/MainActivity;
        val internal = type.removePrefix("L").removeSuffix(";")
        val slash = internal.lastIndexOf('/')
        val packageName = if (slash >= 0) {
            internal.substring(0, slash).replace('/', '.')
        } else {
            ""
        }
        val simpleName = if (slash >= 0) internal.substring(slash + 1) else internal

        val methods = classDef.methods.map { m ->
            DexMethodInfo(
                name = m.name,
                descriptor = m.parameterTypes.joinToString(prefix = "(", postfix = ")") + m.returnType,
                accessFlags = m.accessFlags
            )
        }

        return DexClassInfo(
            type = type,
            simpleName = simpleName,
            packageName = packageName,
            methods = methods
        )
    }
}
