package com.scmanager.app.core.dex

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class DexClassInfo(
    val type: String,
    val simpleName: String,
    val packageName: String,
    val methods: List<DexMethodInfo> = emptyList()
)

data class DexMethodInfo(
    val name: String,
    val descriptor: String,
    val accessFlags: Int = 0
)

data class DexPackageNode(
    val name: String,
    val fullName: String,
    val classes: MutableList<DexClassInfo> = mutableListOf(),
    val children: MutableMap<String, DexPackageNode> = mutableMapOf()
)

class DexService {

    suspend fun openDex(dexPath: String): Result<List<DexClassInfo>> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(dexPath)
            require(file.exists()) { "DEX not found: $dexPath" }
            listOf(
                DexClassInfo(
                    type = "Lcom/scmanager/Placeholder;",
                    simpleName = "Placeholder",
                    packageName = "com.scmanager",
                    methods = listOf(DexMethodInfo("main", "()V"))
                )
            )
        }
    }

    suspend fun openDexFromApk(apkPath: String, entryName: String = "classes.dex"): Result<List<DexClassInfo>> =
        withContext(Dispatchers.IO) { openDex(apkPath) }

    suspend fun classToSmali(dexPath: String, classType: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                """
                # Placeholder smali (enable dexlib2 later)
                .class public $classType
                .super Ljava/lang/Object;
                .method public constructor <init>()V
                    .registers 1
                    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
                    return-void
                .end method
                """.trimIndent()
            }
        }

    suspend fun saveSmaliToDex(dexPath: String, smaliCode: String, outputPath: String): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val out = File(outputPath)
                File(dexPath).copyTo(out, overwrite = true)
                out
            }
        }

    suspend fun saveSmaliInPlace(dexPath: String, smaliCode: String): Result<File> =
        withContext(Dispatchers.IO) { runCatching { File(dexPath) } }

    fun buildPackageTree(classes: List<DexClassInfo>): DexPackageNode {
        val root = DexPackageNode(name = "", fullName = "")
        for (cls in classes) {
            val parts = cls.packageName.split('.').filter { it.isNotBlank() }
            var current = root
            var path = ""
            for (part in parts) {
                path = if (path.isEmpty()) part else "$path.$part"
                current = current.children.getOrPut(part) {
                    DexPackageNode(name = part, fullName = path)
                }
            }
            current.classes.add(cls)
        }
        return root
    }
}
