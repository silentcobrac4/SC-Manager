package com.scmanager.app.core.file

import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class FileRepository {

    fun defaultStoragePath(): String {
        return Environment.getExternalStorageDirectory()?.absolutePath
            ?: "/storage/emulated/0"
    }

    suspend fun list(path: String, showHidden: Boolean = false): Result<List<FileEntry>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(path)
                if (!dir.exists()) error("Path does not exist: $path")
                if (!dir.isDirectory) error("Not a directory: $path")
                if (!dir.canRead()) error("Cannot read: $path")

                val files = dir.listFiles() ?: emptyArray()
                files
                    .filter { showHidden || !it.name.startsWith(".") }
                    .map { f ->
                        val ext = if (f.isFile) {
                            f.name.substringAfterLast('.', missingDelimiterValue = "")
                        } else ""
                        FileEntry(
                            path = f.absolutePath,
                            name = f.name,
                            isDirectory = f.isDirectory,
                            size = if (f.isFile) f.length() else 0L,
                            lastModified = f.lastModified(),
                            extension = ext
                        )
                    }
                    .sortedWith(
                        compareBy<FileEntry> { !it.isDirectory }
                            .thenBy { it.name.lowercase() }
                    )
            }
        }

    suspend fun copy(source: String, destDir: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(source)
            val dest = File(destDir, src.name)
            require(src.exists()) { "Source not found" }
            dest.parentFile?.mkdirs()
            src.copyRecursively(dest, overwrite = true)
            dest
        }
    }

    suspend fun move(source: String, destDir: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(source)
            val dest = File(destDir, src.name)
            require(src.exists()) { "Source not found" }
            dest.parentFile?.mkdirs()
            if (!src.renameTo(dest)) {
                src.copyRecursively(dest, overwrite = true)
                src.deleteRecursively()
            }
            dest
        }
    }

    suspend fun delete(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val f = File(path)
            require(f.exists()) { "Not found: $path" }
            if (f.isDirectory) f.deleteRecursively() else f.delete()
            Unit
        }
    }

    suspend fun rename(path: String, newName: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val f = File(path)
            val dest = File(f.parentFile, newName)
            require(f.exists()) { "Not found" }
            require(!dest.exists()) { "Target already exists" }
            if (!f.renameTo(dest)) error("Rename failed")
            dest
        }
    }

    suspend fun createFolder(parent: String, name: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(parent, name)
            if (!dir.mkdirs() && !dir.exists()) error("Could not create folder")
            dir
        }
    }
}
