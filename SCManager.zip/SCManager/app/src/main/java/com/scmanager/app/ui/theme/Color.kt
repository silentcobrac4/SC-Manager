package com.scmanager.app.ui.theme

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF121212)
val Surface = Color(0xFF1E1E1E)
val SurfaceVariant = Color(0xFF2A2A2A)
val Border = Color(0xFF333333)
val TextPrimary = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFAAAAAA)
val TextDisabled = Color(0xFF666666)
val Accent = Color(0xFF4CAF50)
val OnAccent = Color(0xFF000000)
val Danger = Color(0xFFF44336)
val Success = Color(0xFF4CAF50)
val Warning = Color(0xFFFF9800)
val Info = Color(0xFF2196F3)
val CodeBackground = Color(0xFF1A1A1A)
val Selection = Color(0xFF214283)
