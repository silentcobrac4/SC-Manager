package com.scmanager.app.ui.theme
import androidx.compose.ui.graphics.Color
val Bg = Color(0xFF121212)
val Surface = Color(0xFF1E1E1E)
val TextPrimary = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFAAAAAA)
val Accent = Color(0xFF4CAF50)
val Border = Color(0xFF333333)
