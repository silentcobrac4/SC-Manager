package com.scmanager.app

import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.ui.theme.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SCManagerTheme {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    FileBrowserScreen()
                }
            }
        }
    }
}

data class FileItem(val name: String, val path: String, val isDir: Boolean, val size: Long)

@Composable
fun FileBrowserScreen() {
    val root = remember {
        Environment.getExternalStorageDirectory()?.absolutePath ?: "/storage/emulated/0"
    }
    var path by remember { mutableStateOf(root) }
    var files by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("SC Manager — Dual pane file tools coming next builds") }

    fun load(p: String) {
        try {
            val dir = File(p)
            if (!dir.exists() || !dir.canRead()) {
                error = "Cannot read: $p (grant All files access)"
                files = emptyList()
                return
            }
            error = null
            files = dir.listFiles()
                ?.filter { !it.name.startsWith(".") }
                ?.map {
                    FileItem(it.name, it.absolutePath, it.isDirectory, if (it.isFile) it.length() else 0L)
                }
                ?.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
                ?: emptyList()
            path = p
        } catch (e: Exception) {
            error = e.message
            files = emptyList()
        }
    }

    LaunchedEffect(Unit) { load(path) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Surface).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Menu, null, tint = TextPrimary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SC Manager", color = TextPrimary, fontSize = 18.sp)
                Text(path, color = TextMuted, fontSize = 11.sp, maxLines = 1)
            }
            IconButton(onClick = { load(path) }) {
                Icon(Icons.Default.Refresh, null, tint = Accent)
            }
        }

        if (path != root && path.contains("/")) {
            Text(
                text = "← Parent",
                color = Accent,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val parent = File(path).parent ?: root
                        load(parent)
                    }
                    .padding(12.dp)
            )
        }

        error?.let {
            Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
        }

        Text(message, color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp))

        LazyColumn(Modifier.fillMaxSize()) {
            items(files, key = { it.path }) { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (item.isDir) load(item.path)
                            else message = "Opened: ${item.name}"
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (item.isDir) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                        null,
                        tint = if (item.isDir) Accent else TextMuted
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(item.name, color = TextPrimary, fontSize = 15.sp)
                        if (!item.isDir) {
                            Text("${item.size} B", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                }
                HorizontalDivider(color = Border.copy(alpha = 0.5f))
            }
        }
    }
}
