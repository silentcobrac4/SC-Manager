package com.scmanager.app.core.apk

data class ApkInfo(
    val path: String,
    val fileName: String,
    val packageName: String = "",
    val versionName: String = "",
    val versionCode: Long = 0,
    val minSdk: Int = 0,
    val targetSdk: Int = 0,
    val size: Long = 0,
    val entries: List<ApkEntry> = emptyList()
)

data class ApkEntry(
    val name: String,
    val size: Long,
    val compressedSize: Long,
    val isDirectory: Boolean
)

data class StringResource(
    val key: String,
    val value: String,
    val source: String = "resources" // e.g. values/strings.xml or arsc
)
