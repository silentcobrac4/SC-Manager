package com.scmanager.app.ui.apktools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class KillSigState {
    Idle, Processing, Success, Error
}

@Composable
fun KillSignatureScreen(
    apkName: String,
    apkPath: String,
    onBack: () -> Unit,
    onDone: (outputPath: String) -> Unit
) {
    var signAfter by remember { mutableStateOf(true) }
    var outputName by remember { mutableStateOf(apkName.removeSuffix(".apk") + "_nosigcheck.apk") }

    var state by remember { mutableStateOf(KillSigState.Idle) }
    var progressMessage by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Kill Signature Verification", color = TextPrimary, fontSize = 16.sp)
                Text(
                    text = apkName,
                    color = TextMuted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Source APK", color = TextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(apkPath, color = TextPrimary, fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "What this does",
                        color = TextPrimary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Attempts to disable common signature / integrity checks inside the app so a re-signed APK can still run. This is a best-effort patch and may not work on every app (especially those with native checks or Play Integrity).",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = signAfter,
                            onCheckedChange = { signAfter = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = Accent,
                                uncheckedColor = TextMuted,
                                checkmarkColor = OnAccent
                            )
                        )
                        Text("Sign after patching", color = TextPrimary, fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("Output file name", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = outputName,
                onValueChange = { outputName = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            when (state) {
                KillSigState.Processing -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = Accent,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(progressMessage, color = TextMuted, fontSize = 14.sp)
                    }
                }
                KillSigState.Success -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = Success)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Patch applied", color = Success, fontSize = 14.sp)
                    }
                }
                KillSigState.Error -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Error, null, tint = Danger)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(errorMessage, color = Danger, fontSize = 14.sp)
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    scope.launch {
                        state = KillSigState.Processing
                        progressMessage = "Scanning DEX for signature checks..."
                        delay(700)
                        progressMessage = "Applying patches..."
                        delay(800)
                        if (signAfter) {
                            progressMessage = "Signing..."
                            delay(500)
                        }
                        progressMessage = "Writing output..."
                        delay(300)

                        // Simulated
                        state = KillSigState.Success
                        val outputPath = apkPath.substringBeforeLast("/") + "/" + outputName
                        onDone(outputPath)
                    }
                },
                enabled = state != KillSigState.Processing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Accent,
                    contentColor = OnAccent,
                    disabledContainerColor = SurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Warning, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state == KillSigState.Processing) "Processing..." else "Kill Signature Verification",
                    fontSize = 15.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Note: Currently simulated. Real implementation will search common signature-check patterns in DEX and patch them.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}
