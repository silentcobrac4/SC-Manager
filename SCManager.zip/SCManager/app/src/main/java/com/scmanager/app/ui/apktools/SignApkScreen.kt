package com.scmanager.app.ui.apktools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.scmanager.app.core.apk.ApkService
import com.scmanager.app.ui.theme.*
import kotlinx.coroutines.launch

enum class SignState {
    Idle, Signing, Success, Error
}

@Composable
fun SignApkScreen(
    apkName: String,
    apkPath: String,
    onBack: () -> Unit,
    onSigned: (outputPath: String) -> Unit
) {
    val context = LocalContext.current
    val apkService = remember { ApkService(context) }

    var useV1 by remember { mutableStateOf(true) }
    var useV2 by remember { mutableStateOf(true) }
    var useV3 by remember { mutableStateOf(true) }
    var useDefaultKey by remember { mutableStateOf(true) }
    var outputName by remember { mutableStateOf(apkName.removeSuffix(".apk") + "_signed.apk") }
    var signState by remember { mutableStateOf(SignState.Idle) }
    var errorMessage by remember { mutableStateOf("") }
    var progressMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Sign APK",
                    color = TextPrimary,
                    fontSize = 16.sp
                )
                Text(
                    text = apkName,
                    color = TextMuted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Source info
            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Source", color = TextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(apkPath, color = TextPrimary, fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Signature schemes
            Text("Signature schemes", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SignCheckRow("V1 (JAR signing)", useV1) { useV1 = it }
                    SignCheckRow("V2 (APK Signature Scheme v2)", useV2) { useV2 = it }
                    SignCheckRow("V3 (APK Signature Scheme v3)", useV3) { useV3 = it }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Keystore
            Text("Keystore", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SignCheckRow("Use built-in test key", useDefaultKey) { useDefaultKey = it }
                    if (!useDefaultKey) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "Custom keystore support will be added later",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Output name
            Text("Output file name", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = outputName,
                onValueChange = { outputName = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Status
            when (signState) {
                SignState.Signing -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(
                            color = Accent,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(progressMessage, color = TextMuted, fontSize = 14.sp)
                    }
                }
                SignState.Success -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = Success)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Signed successfully", color = Success, fontSize = 14.sp)
                    }
                }
                SignState.Error -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Error, null, tint = Danger)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(errorMessage, color = Danger, fontSize = 14.sp)
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sign button
            Button(
                onClick = {
                    if (!useV1 && !useV2 && !useV3) {
                        signState = SignState.Error
                        errorMessage = "Select at least one signature scheme"
                        return@Button
                    }
                    scope.launch {
                        signState = SignState.Signing
                        progressMessage = "Signing..."
                        val outputPath = if (apkPath.contains("/")) {
                            apkPath.substringBeforeLast("/") + "/" + outputName
                        } else {
                            outputName
                        }
                        apkService.sign(apkPath, outputPath, useV1, useV2, useV3)
                            .onSuccess {
                                progressMessage = "Done"
                                signState = SignState.Success
                                onSigned(it.absolutePath)
                            }
                            .onFailure {
                                signState = SignState.Error
                                errorMessage = it.message ?: "Sign failed"
                            }
                    }
                },
                enabled = signState != SignState.Signing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Accent,
                    contentColor = OnAccent,
                    disabledContainerColor = SurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (signState == SignState.Signing) "Signing..." else "Sign APK",
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Note: Currently using a simulated sign flow. Real apksig integration will be added next.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun SignCheckRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = Accent,
                uncheckedColor = TextMuted,
                checkmarkColor = OnAccent
            )
        )
        Text(text = label, color = TextPrimary, fontSize = 14.sp)
    }
}
