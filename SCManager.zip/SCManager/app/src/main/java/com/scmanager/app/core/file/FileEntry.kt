package com.scmanager.app.core.file

data class FileEntry(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val size: Long = 0L,
    val lastModified: Long = 0L,
    val extension: String = ""
) {
    val isApk: Boolean
        get() = !isDirectory && extension.equals("apk", ignoreCase = true)

    val isDex: Boolean
        get() = !isDirectory && extension.equals("dex", ignoreCase = true)
}
