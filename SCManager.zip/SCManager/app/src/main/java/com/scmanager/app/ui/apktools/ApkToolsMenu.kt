package com.scmanager.app.ui.apktools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.ui.theme.*

data class ApkTool(
    val id: String,
    val title: String,
    val icon: ImageVector
)

val apkTools = listOf(
    ApkTool("sign", "Sign APK", Icons.Default.Verified),
    ApkTool("clone", "Clone APK", Icons.Default.ContentCopy),
    ApkTool("optimize", "Optimize APK", Icons.Default.Speed),
    ApkTool("dex_redivision", "Dex Redivision", Icons.Default.AccountTree),
    ApkTool("dex_anti_confusion", "Dex Anti-Confusion", Icons.Default.Visibility),
    ApkTool("decrypt_dex_strings", "Decrypt Dex Strings", Icons.Default.LockOpen),
    ApkTool("resources_confusion", "Resources Confusion", Icons.Default.Shuffle),
    ApkTool("resources_anti_confusion", "Resources Anti-Confusion", Icons.Default.ClearAll),
    ApkTool("resources_minification", "Resources Minification", Icons.Default.Compress),
    ApkTool("xml_batch_replacement", "Xml Batch Replacement", Icons.Default.FindReplace),
    ApkTool("xml_translation", "Xml Translation Mode", Icons.Default.Translate),
    ApkTool("kill_signature", "Kill Signature Verification", Icons.Default.GppBad),
    ApkTool("apk_data_multiplexing", "APK Data Multiplexing", Icons.Default.Layers),
    ApkTool("inject_documents_provider", "Inject Documents Provider", Icons.Default.FolderShared),
    ApkTool("inject_logging", "Inject Logging", Icons.Default.BugReport)
)

@Composable
fun ApkToolsBottomSheet(
    apkPath: String,
    apkName: String,
    onDismiss: () -> Unit,
    onToolSelected: (ApkTool) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Surface,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            Text(
                text = apkName,
                color = TextPrimary,
                fontSize = 16.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
            )
            Text(
                text = apkPath,
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 0.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Border)

            LazyColumn {
                items(apkTools) { tool ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToolSelected(tool) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = tool.icon,
                            contentDescription = null,
                            tint = Accent,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = tool.title,
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
