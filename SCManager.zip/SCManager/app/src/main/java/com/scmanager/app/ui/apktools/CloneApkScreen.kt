package com.scmanager.app.ui.apktools

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class CloneState {
    Idle, Cloning, Success, Error
}

@Composable
fun CloneApkScreen(
    apkName: String,
    apkPath: String,
    onBack: () -> Unit,
    onCloned: (outputPath: String) -> Unit
) {
    // Suggested new package name based on original name
    val baseName = apkName.removeSuffix(".apk")
    var newPackageName by remember { mutableStateOf("com.scmanager.clone.$baseName") }
    var newAppLabel by remember { mutableStateOf("$baseName Clone") }
    var changeIcon by remember { mutableStateOf(false) }
    var signAfterClone by remember { mutableStateOf(true) }
    var outputName by remember { mutableStateOf("${baseName}_clone.apk") }

    var cloneState by remember { mutableStateOf(CloneState.Idle) }
    var progressMessage by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Clone APK", color = TextPrimary, fontSize = 16.sp)
                Text(
                    text = apkName,
                    color = TextMuted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Source
            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Source APK", color = TextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(apkPath, color = TextPrimary, fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // New package name
            Text("New package name", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = newPackageName,
                onValueChange = { newPackageName = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                )
            )
            Text(
                text = "Must be unique so the clone can be installed alongside the original",
                color = TextMuted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // New app label
            Text("New app name (label)", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = newAppLabel,
                onValueChange = { newAppLabel = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Options
            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    CloneCheckRow(
                        label = "Sign after cloning",
                        checked = signAfterClone,
                        onCheckedChange = { signAfterClone = it }
                    )
                    CloneCheckRow(
                        label = "Change app icon (placeholder)",
                        checked = changeIcon,
                        onCheckedChange = { changeIcon = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Output name
            Text("Output file name", color = TextPrimary, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = outputName,
                onValueChange = { outputName = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Border,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = Accent
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Status
            when (cloneState) {
                CloneState.Cloning -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(
                            color = Accent,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(progressMessage, color = TextMuted, fontSize = 14.sp)
                    }
                }
                CloneState.Success -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = Success)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Clone created successfully", color = Success, fontSize = 14.sp)
                    }
                }
                CloneState.Error -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Error, null, tint = Danger)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(errorMessage, color = Danger, fontSize = 14.sp)
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Clone button
            Button(
                onClick = {
                    if (newPackageName.isBlank()) {
                        cloneState = CloneState.Error
                        errorMessage = "Package name cannot be empty"
                        return@Button
                    }
                    if (!newPackageName.matches(Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+$"))) {
                        cloneState = CloneState.Error
                        errorMessage = "Invalid package name format"
                        return@Button
                    }

                    scope.launch {
                        cloneState = CloneState.Cloning
                        progressMessage = "Reading APK..."
                        delay(500)
                        progressMessage = "Updating package name & label..."
                        delay(700)
                        progressMessage = "Rebuilding resources..."
                        delay(600)
                        if (signAfterClone) {
                            progressMessage = "Signing clone..."
                            delay(500)
                        }
                        progressMessage = "Writing output..."
                        delay(400)

                        // TODO: real clone logic (change package in AndroidManifest + resources + sign)
                        cloneState = CloneState.Success
                        val outputPath = apkPath.substringBeforeLast("/") + "/" + outputName
                        onCloned(outputPath)
                    }
                },
                enabled = cloneState != CloneState.Cloning,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Accent,
                    contentColor = OnAccent,
                    disabledContainerColor = SurfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (cloneState == CloneState.Cloning) "Cloning..." else "Clone APK",
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Note: Currently simulated. Real implementation will update AndroidManifest.xml, resources.arsc and optionally sign the result.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun CloneCheckRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = Accent,
                uncheckedColor = TextMuted,
                checkmarkColor = OnAccent
            )
        )
        Text(text = label, color = TextPrimary, fontSize = 14.sp)
    }
}
