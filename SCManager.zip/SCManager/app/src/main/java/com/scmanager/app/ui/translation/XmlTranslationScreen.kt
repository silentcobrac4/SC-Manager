package com.scmanager.app.ui.translation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.core.apk.ApkService
import com.scmanager.app.core.apk.StringResource
import com.scmanager.app.ui.theme.*

@Composable
fun XmlTranslationScreen(
    apkName: String,
    apkPath: String = "",
    onBack: () -> Unit,
    onSave: (List<StringResource>) -> Unit
) {
    val context = LocalContext.current
    val apkService = remember { ApkService(context) }

    var strings by remember { mutableStateOf<List<StringResource>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var selectedTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var editingKey by remember { mutableStateOf<String?>(null) }
    var editValue by remember { mutableStateOf("") }
    var hasChanges by remember { mutableStateOf(false) }

    LaunchedEffect(apkPath) {
        isLoading = true
        loadError = null
        if (apkPath.isBlank()) {
            strings = sampleStrings()
            isLoading = false
            return@LaunchedEffect
        }
        apkService.readStrings(apkPath)
            .onSuccess {
                strings = it
                isLoading = false
            }
            .onFailure {
                loadError = it.message
                strings = sampleStrings()
                isLoading = false
            }
    }

    val filtered = remember(strings, searchQuery) {
        if (searchQuery.isBlank()) strings
        else strings.filter {
            it.key.contains(searchQuery, ignoreCase = true) ||
                    it.value.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Surface)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Xml Translation Mode", color = TextPrimary, fontSize = 16.sp)
                Text(
                    text = apkName,
                    color = TextMuted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (hasChanges) {
                IconButton(onClick = { onSave(strings) }) {
                    Icon(Icons.Default.Check, contentDescription = "Save", tint = Accent)
                }
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Surface,
            contentColor = Accent
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("String", color = if (selectedTab == 0) Accent else TextMuted) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Files", color = if (selectedTab == 1) Accent else TextMuted) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Manifest", color = if (selectedTab == 2) Accent else TextMuted) }
            )
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Input keyword to search", color = TextMuted) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Border,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = Accent
            )
        )

        when {
            isLoading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Accent)
                }
            }
            selectedTab == 0 -> {
                if (loadError != null) {
                    Text(
                        text = "Load warning: $loadError",
                        color = Warning,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filtered, key = { it.key }) { item ->
                        if (editingKey == item.key) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SurfaceVariant)
                                    .padding(12.dp)
                            ) {
                                Text(item.key, color = TextMuted, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = editValue,
                                    onValueChange = { editValue = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = Accent,
                                        unfocusedBorderColor = Border,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        cursorColor = Accent
                                    )
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    TextButton(onClick = { editingKey = null }) {
                                        Text("Cancel", color = TextMuted)
                                    }
                                    TextButton(onClick = {
                                        strings = strings.map {
                                            if (it.key == item.key) it.copy(value = editValue) else it
                                        }
                                        hasChanges = true
                                        editingKey = null
                                    }) {
                                        Text("Save", color = Accent)
                                    }
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        editingKey = item.key
                                        editValue = item.value
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.key,
                                        color = TextMuted,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = item.value,
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = "Edit",
                                    tint = TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            HorizontalDivider(color = Border.copy(alpha = 0.5f))
                        }
                    }
                }
            }
            selectedTab == 1 -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Files view – coming soon", color = TextMuted)
                }
            }
            else -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Manifest view – coming soon", color = TextMuted)
                }
            }
        }
    }
}

private fun sampleStrings() = listOf(
    StringResource("app_name", "Example App"),
    StringResource("ok", "OK"),
    StringResource("cancel", "Cancel"),
    StringResource("settings", "Settings"),
    StringResource(
        "_info",
        "Sample data – open a real APK to load strings from XML inside the package"
    )
)
