package com.scmanager.app.core.apk

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Core APK read / write operations.
 * Uses standard Zip APIs. DEX/Smali and full ARSC editing will plug in later (dexlib2 / arsc parser).
 */
class ApkService(private val context: Context) {

    // ---------- Read ----------

    suspend fun open(apkPath: String): Result<ApkInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(apkPath)
            require(file.exists() && file.isFile) { "APK not found: $apkPath" }

            val entries = mutableListOf<ApkEntry>()
            ZipFile(file).use { zip ->
                val enumeration = zip.entries()
                while (enumeration.hasMoreElements()) {
                    val e = enumeration.nextElement()
                    entries.add(
                        ApkEntry(
                            name = e.name,
                            size = e.size,
                            compressedSize = e.compressedSize,
                            isDirectory = e.isDirectory
                        )
                    )
                }
            }

            // Try to get package info via PackageManager if installed path, else basic from file
            val packageInfo = tryGetPackageInfo(apkPath)

            ApkInfo(
                path = apkPath,
                fileName = file.name,
                packageName = packageInfo?.packageName ?: "",
                versionName = packageInfo?.versionName ?: "",
                versionCode = if (Build.VERSION.SDK_INT >= 28) {
                    packageInfo?.longVersionCode ?: 0
                } else {
                    @Suppress("DEPRECATION")
                    packageInfo?.versionCode?.toLong() ?: 0
                },
                size = file.length(),
                entries = entries.sortedBy { it.name }
            )
        }
    }

    private fun tryGetPackageInfo(apkPath: String): android.content.pm.PackageInfo? {
        return try {
            context.packageManager.getPackageArchiveInfo(apkPath, 0)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Extract a single entry from APK to a target file.
     */
    suspend fun extractEntry(apkPath: String, entryName: String, destFile: File): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                ZipFile(File(apkPath)).use { zip ->
                    val entry = zip.getEntry(entryName)
                        ?: error("Entry not found: $entryName")
                    destFile.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input ->
                        FileOutputStream(destFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }
                destFile
            }
        }

    /**
     * Extract entire APK contents to a directory (for advanced editing).
     */
    suspend fun extractAll(apkPath: String, destDir: File): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            destDir.mkdirs()
            ZipFile(File(apkPath)).use { zip ->
                val enumeration = zip.entries()
                while (enumeration.hasMoreElements()) {
                    val entry = enumeration.nextElement()
                    val outFile = File(destDir, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        zip.getInputStream(entry).use { input ->
                            FileOutputStream(outFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                    }
                }
            }
            destDir
        }
    }

    /**
     * Read string resources by scanning XML files inside the APK (simple regex-based).
     * Full ARSC binary parser will replace this later.
     */
    suspend fun readStrings(apkPath: String): Result<List<StringResource>> = withContext(Dispatchers.IO) {
        runCatching {
            val strings = mutableListOf<StringResource>()
            val seen = mutableSetOf<String>()

            ZipFile(File(apkPath)).use { zip ->
                val enumeration = zip.entries()
                while (enumeration.hasMoreElements()) {
                    val entry = enumeration.nextElement()
                    if (entry.isDirectory) continue
                    val name = entry.name
                    // Look for values*/strings*.xml
                    if (name.contains("values") && name.endsWith(".xml") && name.contains("string")) {
                        val content = zip.getInputStream(entry).bufferedReader().readText()
                        parseStringsXml(content, name).forEach { sr ->
                            if (seen.add(sr.key)) {
                                strings.add(sr)
                            }
                        }
                    }
                }
            }

            // If nothing found in plain XML (most modern APKs keep strings in resources.arsc only),
            // return a helpful placeholder so UI still works.
            if (strings.isEmpty()) {
                strings.add(
                    StringResource(
                        key = "_info",
                        value = "No plain strings.xml found. Full ARSC parser needed for binary resources.",
                        source = "info"
                    )
                )
            }

            strings.sortedBy { it.key }
        }
    }

    private fun parseStringsXml(xml: String, source: String): List<StringResource> {
        val result = mutableListOf<StringResource>()
        // <string name="key">value</string>
        val regex = Regex("""<string\s+name="([^"]+)"[^>]*>([^<]*)</string>""")
        regex.findAll(xml).forEach { match ->
            val key = match.groupValues[1]
            val value = match.groupValues[2]
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("\\n", "\n")
                .replace("\\'", "'")
            result.add(StringResource(key = key, value = value, source = source))
        }
        return result
    }

    // ---------- Write / transform ----------

    /**
     * Copy APK to a new path (base for clone / optimize / sign pipelines).
     */
    suspend fun copyApk(sourcePath: String, destPath: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(sourcePath)
            val dest = File(destPath)
            dest.parentFile?.mkdirs()
            src.copyTo(dest, overwrite = true)
            dest
        }
    }

    /**
     * Replace one entry inside an APK (e.g. updated classes.dex or AndroidManifest.xml).
     * Creates a new ZIP with the replacement.
     */
    suspend fun replaceEntry(
        apkPath: String,
        entryName: String,
        newContent: ByteArray,
        outputPath: String
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(apkPath)
            val out = File(outputPath)
            out.parentFile?.mkdirs()

            ZipFile(src).use { zipIn ->
                ZipOutputStream(FileOutputStream(out)).use { zipOut ->
                    val enumeration = zipIn.entries()
                    while (enumeration.hasMoreElements()) {
                        val entry = enumeration.nextElement()
                        if (entry.name == entryName) continue // skip old
                        val newEntry = ZipEntry(entry.name).apply {
                            method = entry.method
                            if (entry.method == ZipEntry.STORED) {
                                size = entry.size
                                compressedSize = entry.compressedSize
                                crc = entry.crc
                            }
                        }
                        zipOut.putNextEntry(newEntry)
                        if (!entry.isDirectory) {
                            zipIn.getInputStream(entry).use { it.copyTo(zipOut) }
                        }
                        zipOut.closeEntry()
                    }
                    // write new entry
                    val replacement = ZipEntry(entryName)
                    zipOut.putNextEntry(replacement)
                    zipOut.write(newContent)
                    zipOut.closeEntry()
                }
            }
            out
        }
    }

    /**
     * Simple "optimize": recompress all entries with default Deflate.
     * Real zipalign / resource shrinking comes later.
     */
    suspend fun recompress(apkPath: String, outputPath: String): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val src = File(apkPath)
            val out = File(outputPath)
            out.parentFile?.mkdirs()

            ZipFile(src).use { zipIn ->
                ZipOutputStream(FileOutputStream(out)).use { zipOut ->
                    zipOut.setLevel(9)
                    val enumeration = zipIn.entries()
                    while (enumeration.hasMoreElements()) {
                        val entry = enumeration.nextElement()
                        val newEntry = ZipEntry(entry.name)
                        zipOut.putNextEntry(newEntry)
                        if (!entry.isDirectory) {
                            zipIn.getInputStream(entry).use { it.copyTo(zipOut) }
                        }
                        zipOut.closeEntry()
                    }
                }
            }
            out
        }
    }

    /**
     * Extract installed app APK to a destination path.
     */
    suspend fun extractInstalledApk(sourceDir: String, destPath: String): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val src = File(sourceDir)
                require(src.exists()) { "Source APK not found" }
                val dest = File(destPath)
                dest.parentFile?.mkdirs()
                src.copyTo(dest, overwrite = true)
                dest
            }
        }

    // ---------- Sign (stub ready for apksig) ----------

    /**
     * Placeholder sign. Real implementation will use com.android.tools.build:apksig.
     * For now copies the file and returns it so the UI flow works end-to-end.
     */
    suspend fun sign(
        apkPath: String,
        outputPath: String,
        v1: Boolean = true,
        v2: Boolean = true,
        v3: Boolean = true
    ): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            // TODO: integrate apksig library
            // ApkSigner.Builder(...).setV1SigningEnabled(v1)...build().sign()
            val src = File(apkPath)
            val dest = File(outputPath)
            dest.parentFile?.mkdirs()
            if (src.absolutePath != dest.absolutePath) {
                src.copyTo(dest, overwrite = true)
            }
            dest
        }
    }
}
