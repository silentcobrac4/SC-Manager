package com.scmanager.app.ui.explorer

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.scmanager.app.core.file.FileEntry
import com.scmanager.app.core.file.FileRepository
import com.scmanager.app.ui.apktools.ApkTool
import kotlinx.coroutines.launch
import com.scmanager.app.ui.apktools.ApkToolsBottomSheet
import com.scmanager.app.ui.apktools.CloneApkScreen
import com.scmanager.app.ui.apktools.KillSignatureScreen
import com.scmanager.app.ui.apktools.OptimizeApkScreen
import com.scmanager.app.ui.apktools.SignApkScreen
import com.scmanager.app.ui.dex.DexEditorScreen
import com.scmanager.app.ui.dex.DexNode
import com.scmanager.app.ui.dex.SmaliEditorScreen
import com.scmanager.app.ui.extract.ExtractApkScreen
import com.scmanager.app.ui.extract.InstalledApp
import com.scmanager.app.ui.theme.*
import com.scmanager.app.ui.translation.XmlTranslationScreen

sealed class Screen {
    object Explorer : Screen()
    object ExtractApk : Screen()
    data class XmlTranslation(val apkName: String, val apkPath: String) : Screen()
    data class SignApk(val apkName: String, val apkPath: String) : Screen()
    data class CloneApk(val apkName: String, val apkPath: String) : Screen()
    data class OptimizeApk(val apkName: String, val apkPath: String) : Screen()
    data class KillSignature(val apkName: String, val apkPath: String) : Screen()
    data class DexEditor(val dexName: String = "classes.dex", val dexPath: String = "") : Screen()
    data class SmaliEditor(val className: String, val dexPath: String = "") : Screen()
}

@Composable
fun ExplorerScreen() {
    val fileRepo = remember { FileRepository() }
    val defaultPath = remember { fileRepo.defaultStoragePath() }

    var currentScreen by remember { mutableStateOf<Screen>(Screen.Explorer) }
    var leftPath by remember { mutableStateOf(defaultPath) }
    var rightPath by remember { mutableStateOf(defaultPath) }
    var leftFiles by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var rightFiles by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var leftLoading by remember { mutableStateOf(true) }
    var rightLoading by remember { mutableStateOf(true) }
    var leftError by remember { mutableStateOf<String?>(null) }
    var rightError by remember { mutableStateOf<String?>(null) }
    var showSidebar by remember { mutableStateOf(false) }
    var selectedApk by remember { mutableStateOf<FileEntry?>(null) }
    var showApkTools by remember { mutableStateOf(false) }

    // Dual-pane selection / ops
    var activePane by remember { mutableStateOf("left") } // left | right
    var multiSelect by remember { mutableStateOf(false) }
    var selectedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var opMessage by remember { mutableStateOf<String?>(null) }
    var isOperating by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var leftRefresh by remember { mutableStateOf(0) }
    var rightRefresh by remember { mutableStateOf(0) }

    suspend fun refreshLeft() {
        leftLoading = true
        leftError = null
        fileRepo.list(leftPath)
            .onSuccess { leftFiles = it; leftLoading = false }
            .onFailure { leftError = it.message; leftFiles = emptyList(); leftLoading = false }
    }

    suspend fun refreshRight() {
        rightLoading = true
        rightError = null
        fileRepo.list(rightPath)
            .onSuccess { rightFiles = it; rightLoading = false }
            .onFailure { rightError = it.message; rightFiles = emptyList(); rightLoading = false }
    }

    LaunchedEffect(leftPath, leftRefresh) { refreshLeft() }
    LaunchedEffect(rightPath, rightRefresh) { refreshRight() }

    fun toggleSelect(path: String) {
        selectedPaths = if (path in selectedPaths) selectedPaths - path else selectedPaths + path
    }

    fun selectedEntries(): List<FileEntry> {
        val pool = leftFiles + rightFiles
        return pool.filter { it.path in selectedPaths }
    }

    fun runCopy(toRight: Boolean) {
        val targets = selectedEntries()
        if (targets.isEmpty()) {
            opMessage = "No files selected"
            return
        }
        val dest = if (toRight) rightPath else leftPath
        scope.launch {
            isOperating = true
            var ok = 0
            var fail = 0
            for (entry in targets) {
                fileRepo.copy(entry.path, dest)
                    .onSuccess { ok++ }
                    .onFailure { fail++ }
            }
            opMessage = "Copied $ok" + if (fail > 0) ", failed $fail" else ""
            selectedPaths = emptySet()
            multiSelect = false
            leftRefresh++
            rightRefresh++
            isOperating = false
        }
    }

    fun runMove(toRight: Boolean) {
        val targets = selectedEntries()
        if (targets.isEmpty()) {
            opMessage = "No files selected"
            return
        }
        val dest = if (toRight) rightPath else leftPath
        scope.launch {
            isOperating = true
            var ok = 0
            var fail = 0
            for (entry in targets) {
                fileRepo.move(entry.path, dest)
                    .onSuccess { ok++ }
                    .onFailure { fail++ }
            }
            opMessage = "Moved $ok" + if (fail > 0) ", failed $fail" else ""
            selectedPaths = emptySet()
            multiSelect = false
            leftRefresh++
            rightRefresh++
            isOperating = false
        }
    }

    fun runDelete() {
        val targets = selectedEntries()
        if (targets.isEmpty()) {
            opMessage = "No files selected"
            return
        }
        scope.launch {
            isOperating = true
            var ok = 0
            var fail = 0
            for (entry in targets) {
                fileRepo.delete(entry.path)
                    .onSuccess { ok++ }
                    .onFailure { fail++ }
            }
            opMessage = "Deleted $ok" + if (fail > 0) ", failed $fail" else ""
            selectedPaths = emptySet()
            multiSelect = false
            leftRefresh++
            rightRefresh++
            isOperating = false
        }
    }

    when (val screen = currentScreen) {
        is Screen.ExtractApk -> {
            ExtractApkScreen(
                onBack = { currentScreen = Screen.Explorer },
                onExtract = { app: InstalledApp, savedPath: String ->
                    currentScreen = Screen.Explorer
                }
            )
        }
        is Screen.XmlTranslation -> {
            XmlTranslationScreen(
                apkName = screen.apkName,
                apkPath = screen.apkPath,
                onBack = { currentScreen = Screen.Explorer },
                onSave = { updatedStrings ->
                    // TODO: write string changes back into APK (ARSC / XML)
                    currentScreen = Screen.Explorer
                }
            )
        }
        is Screen.SignApk -> {
            SignApkScreen(
                apkName = screen.apkName,
                apkPath = screen.apkPath,
                onBack = { currentScreen = Screen.Explorer },
                onSigned = { outputPath ->
                    // TODO: show success toast / refresh list
                    currentScreen = Screen.Explorer
                }
            )
        }
        is Screen.CloneApk -> {
            CloneApkScreen(
                apkName = screen.apkName,
                apkPath = screen.apkPath,
                onBack = { currentScreen = Screen.Explorer },
                onCloned = { outputPath ->
                    // TODO: show success toast / refresh list
                    currentScreen = Screen.Explorer
                }
            )
        }
        is Screen.OptimizeApk -> {
            OptimizeApkScreen(
                apkName = screen.apkName,
                apkPath = screen.apkPath,
                onBack = { currentScreen = Screen.Explorer },
                onOptimized = { outputPath ->
                    currentScreen = Screen.Explorer
                }
            )
        }
        is Screen.KillSignature -> {
            KillSignatureScreen(
                apkName = screen.apkName,
                apkPath = screen.apkPath,
                onBack = { currentScreen = Screen.Explorer },
                onDone = { outputPath ->
                    currentScreen = Screen.Explorer
                }
            )
        }
        is Screen.DexEditor -> {
            DexEditorScreen(
                dexName = screen.dexName,
                dexPath = screen.dexPath,
                onBack = { currentScreen = Screen.Explorer },
                onOpenClass = { clazz: DexNode.Class ->
                    currentScreen = Screen.SmaliEditor(
                        className = clazz.fullName,
                        dexPath = screen.dexPath
                    )
                }
            )
        }
        is Screen.SmaliEditor -> {
            SmaliEditorScreen(
                className = screen.className,
                dexPath = screen.dexPath,
                onBack = {
                    currentScreen = Screen.DexEditor(
                        dexName = screen.dexPath.substringAfterLast('/').ifEmpty { "classes.dex" },
                        dexPath = screen.dexPath
                    )
                },
                onSave = { newCode ->
                    // TODO: assemble smali back to DEX with smali library
                    currentScreen = Screen.DexEditor(
                        dexName = screen.dexPath.substringAfterLast('/').ifEmpty { "classes.dex" },
                        dexPath = screen.dexPath
                    )
                }
            )
        }
        is Screen.Explorer -> {
            Box(modifier = Modifier.fillMaxSize().background(Bg)) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Surface)
                            .padding(horizontal = 8.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showSidebar = true }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = TextPrimary)
                        }
                        Text(
                            text = "SC Manager",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { }) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = TextPrimary)
                        }
                        IconButton(onClick = { }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary)
                        }
                    }

                    Row(modifier = Modifier.weight(1f)) {
                        FilePane(
                            path = leftPath,
                            files = leftFiles,
                            isLoading = leftLoading,
                            error = leftError,
                            multiSelect = multiSelect,
                            selectedPaths = selectedPaths,
                            onToggleSelect = { toggleSelect(it) },
                            modifier = Modifier.weight(1f),
                            onPathChange = { leftPath = it },
                            onFileClick = { file ->
                                when {
                                    file.isDirectory -> leftPath = file.path
                                    file.isDex -> currentScreen = Screen.DexEditor(
                                        dexName = file.name,
                                        dexPath = file.path
                                    )
                                }
                            },
                            onApkLongClick = { file ->
                                selectedApk = file
                                showApkTools = true
                            }
                        )

                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .fillMaxHeight()
                                .background(Border)
                        )

                        FilePane(
                            path = rightPath,
                            files = rightFiles,
                            isLoading = rightLoading,
                            error = rightError,
                            multiSelect = multiSelect,
                            selectedPaths = selectedPaths,
                            onToggleSelect = { toggleSelect(it) },
                            modifier = Modifier.weight(1f),
                            onPathChange = { rightPath = it },
                            onFileClick = { file ->
                                when {
                                    file.isDirectory -> rightPath = file.path
                                    file.isDex -> currentScreen = Screen.DexEditor(
                                        dexName = file.name,
                                        dexPath = file.path
                                    )
                                }
                            },
                            onApkLongClick = { file ->
                                selectedApk = file
                                showApkTools = true
                            }
                        )
                    }

                    // Status message
                    opMessage?.let { msg ->
                        Text(
                            text = msg,
                            color = Accent,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    // Bottom toolbar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Surface)
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Multi-select toggle
                        IconButton(onClick = {
                            multiSelect = !multiSelect
                            if (!multiSelect) selectedPaths = emptySet()
                        }) {
                            Icon(
                                Icons.Default.CheckBox,
                                null,
                                tint = if (multiSelect) Accent else TextMuted
                            )
                        }
                        // Copy → right pane
                        IconButton(
                            onClick = { runCopy(toRight = true) },
                            enabled = !isOperating && selectedPaths.isNotEmpty()
                        ) {
                            Icon(Icons.Default.ContentCopy, null, tint = if (selectedPaths.isNotEmpty()) Accent else TextMuted)
                        }
                        // Move → right pane
                        IconButton(
                            onClick = { runMove(toRight = true) },
                            enabled = !isOperating && selectedPaths.isNotEmpty()
                        ) {
                            Icon(Icons.Default.DriveFileMove, null, tint = if (selectedPaths.isNotEmpty()) Accent else TextMuted)
                        }
                        // Delete
                        IconButton(
                            onClick = { runDelete() },
                            enabled = !isOperating && selectedPaths.isNotEmpty()
                        ) {
                            Icon(Icons.Default.Delete, null, tint = if (selectedPaths.isNotEmpty()) Danger else TextMuted)
                        }
                        // Sync both panes to same path (right = left)
                        IconButton(onClick = {
                            rightPath = leftPath
                            rightRefresh++
                        }) {
                            Icon(Icons.Default.Sync, null, tint = Accent)
                        }
                        // Refresh
                        IconButton(onClick = {
                            leftRefresh++
                            rightRefresh++
                        }) {
                            Icon(Icons.Default.Refresh, null, tint = TextMuted)
                        }
                    }
                }

                if (showSidebar) {
                    Sidebar(
                        onDismiss = { showSidebar = false },
                        onExtractApk = {
                            showSidebar = false
                            currentScreen = Screen.ExtractApk
                        }
                    )
                }

                if (showApkTools && selectedApk != null) {
                    ApkToolsBottomSheet(
                        apkPath = selectedApk!!.path,
                        apkName = selectedApk!!.name,
                        onDismiss = {
                            showApkTools = false
                            selectedApk = null
                        },
                        onToolSelected = { tool: ApkTool ->
                            showApkTools = false
                            val name = selectedApk?.name ?: "APK"
                            val path = selectedApk?.path ?: ""
                            when (tool.id) {
                                "xml_translation" -> {
                                    currentScreen = Screen.XmlTranslation(
                                        apkName = name,
                                        apkPath = path
                                    )
                                }
                                "sign" -> {
                                    currentScreen = Screen.SignApk(
                                        apkName = name,
                                        apkPath = path
                                    )
                                }
                                "clone" -> {
                                    currentScreen = Screen.CloneApk(
                                        apkName = name,
                                        apkPath = path
                                    )
                                }
                                "optimize" -> {
                                    currentScreen = Screen.OptimizeApk(
                                        apkName = name,
                                        apkPath = path
                                    )
                                }
                                "kill_signature" -> {
                                    currentScreen = Screen.KillSignature(
                                        apkName = name,
                                        apkPath = path
                                    )
                                }
                                // Other tools will be wired later
                                else -> { /* TODO */ }
                            }
                            selectedApk = null
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun FilePane(
    path: String,
    files: List<FileEntry>,
    isLoading: Boolean = false,
    error: String? = null,
    multiSelect: Boolean = false,
    selectedPaths: Set<String> = emptySet(),
    onToggleSelect: (String) -> Unit = {},
    modifier: Modifier = Modifier,
    onPathChange: (String) -> Unit,
    onFileClick: (FileEntry) -> Unit,
    onApkLongClick: (FileEntry) -> Unit
) {
    Column(modifier = modifier.background(Bg)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceVariant)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Parent directory
            if (path != "/" && path.count { it == '/' } > 1) {
                IconButton(
                    onClick = {
                        val parent = path.substringBeforeLast('/').ifEmpty { "/" }
                        onPathChange(parent)
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.ArrowUpward, null, tint = TextMuted, modifier = Modifier.size(18.dp))
                }
            }
            Text(
                text = path,
                color = TextMuted,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }

        when {
            isLoading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Accent, modifier = Modifier.size(28.dp))
                }
            }
            error != null -> {
                Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                    Text(error, color = Danger, fontSize = 13.sp)
                }
            }
            files.isEmpty() -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Empty folder", color = TextMuted, fontSize = 13.sp)
                }
            }
            else -> {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(files, key = { it.path }) { file ->
                        FileListItem(
                            file = file,
                            selected = file.path in selectedPaths,
                            onClick = {
                                if (multiSelect) onToggleSelect(file.path)
                                else onFileClick(file)
                            },
                            onLongClick = {
                                if (file.isApk && !multiSelect) onApkLongClick(file)
                                else onToggleSelect(file.path)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FileListItem(
    file: FileEntry,
    selected: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) Selection.copy(alpha = 0.35f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selected) {
            Icon(Icons.Default.CheckCircle, null, tint = Accent, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(10.dp))
        }
        Icon(
            imageVector = when {
                file.isDirectory -> Icons.Default.Folder
                file.isApk -> Icons.Default.Android
                file.isDex -> Icons.Default.Code
                else -> Icons.Default.InsertDriveFile
            },
            contentDescription = null,
            tint = if (file.isApk || file.isDex) Accent else TextMuted,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = file.name,
                color = TextPrimary,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!file.isDirectory) {
                Text(
                    text = formatSize(file.size),
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun Sidebar(
    onDismiss: () -> Unit,
    onExtractApk: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(onClick = onDismiss)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .width(280.dp)
                .background(Surface)
                .clickable(enabled = false) {}
        ) {
            Text(
                text = "SC Manager",
                color = TextPrimary,
                fontSize = 18.sp,
                modifier = Modifier.padding(16.dp)
            )
            HorizontalDivider(color = Border)

            Text(
                text = "Local",
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
            )
            SidebarItem(Icons.Default.PhoneAndroid, "Root Directory") {}
            SidebarItem(Icons.Default.Storage, "Storage Directory") {}

            Text(
                text = "Tools",
                color = TextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp)
            )
            SidebarItem(Icons.Default.Extension, "Plugin Manager") {}
            SidebarItem(Icons.Default.Cloud, "Remote Management") {}
            SidebarItem(Icons.Default.Colorize, "Screen Color Picker") {}
            SidebarItem(Icons.Default.GetApp, "Extract APK", onClick = onExtractApk)
            SidebarItem(Icons.Default.Edit, "Text Editor") {}
            SidebarItem(Icons.Default.Terminal, "Terminal Simulator") {}
            SidebarItem(Icons.Default.History, "Activity Record") {}
            SidebarItem(Icons.Default.Code, "Smali Instructions") {}
        }
    }
}

@Composable
private fun SidebarItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = TextMuted, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = label, color = TextPrimary, fontSize = 15.sp)
    }
}

private fun formatSize(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
        else -> "%.1f GB".format(bytes / (1024.0 * 1024 * 1024))
    }
}
